import { useEffect, useState } from "react";
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useNavigate, Link } from "react-router-dom";
import ModernDashboardLayout from "@/components/layout/modern-dashboard-layout";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { LoadingSpinner } from "@/components/ui/loading-spinner";
import { 
  Calendar,
  Clock,
  MessageCircle,
  TrendingUp,
  Search,
  Filter,
  BarChart3,
  User,
  Target,
  Star
} from "lucide-react";
import { format, isToday, isYesterday, isThisWeek, isThisMonth } from "date-fns";

interface TranscriptData {
  id: string;
  skill_name: string;
  skill_id: number;
  scenario_name: string;
  context: string;
  instructions: string;
  scenario_context: string;
  scenario_instructions: string;
  duration: number;
  message_count: number;
  created_at: string;
  session_id: string;
  avatar_id: string;
}

interface GroupedTranscripts {
  [key: string]: {
    [skillArea: string]: TranscriptData[];
  };
}

const getTimeGroup = (dateString: string) => {
  const date = new Date(dateString);
  
  if (isToday(date)) return "Today";
  if (isYesterday(date)) return "Yesterday";
  if (isThisWeek(date)) return "This Week";
  if (isThisMonth(date)) return "This Month";
  return "Older";
};

const formatDuration = (seconds: number) => {
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = seconds % 60;
  return `${minutes}m ${remainingSeconds}s`;
};

const getSkillColor = (skillName: string) => {
  const colors = [
    "bg-blue-100 text-blue-800",
    "bg-green-100 text-green-800", 
    "bg-purple-100 text-purple-800",
    "bg-pink-100 text-pink-800",
    "bg-orange-100 text-orange-800",
    "bg-teal-100 text-teal-800",
    "bg-indigo-100 text-indigo-800",
    "bg-red-100 text-red-800",
  ];
  
  const index = skillName?.length ? skillName.length % colors.length : 0;
  return colors[index];
};

export default function ResultsPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedSkill, setSelectedSkill] = useState<string>("");

  return (
    <ModernDashboardLayout>
      <div className="container mx-auto p-8">
        <div className="flex items-center gap-4 mb-6">
          <Link
            to="/avatar/practice"
            className="text-gray-500 hover:text-gray-700"
          >
            ← Back to Practice
          </Link>
          <h1 className="text-3xl font-bold">Practice Session Results</h1>
        </div>
        
        {/* Search and Filters */}
        <div className="flex gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search sessions by skill or scenario..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <Button variant="outline" className="flex items-center gap-2">
            <Filter className="h-4 w-4" />
            Filter by Skill
          </Button>
        </div>

        <SessionResults searchTerm={searchTerm} selectedSkill={selectedSkill} />
      </div>
    </ModernDashboardLayout>
  );
}

export const SessionResults = ({ 
  userId, 
  searchTerm = "", 
  selectedSkill = "" 
}: { 
  userId?: number;
  searchTerm?: string;
  selectedSkill?: string;
}) => {
  const navigate = useNavigate();
  const { user } = useAuth();
  
  const fetchTranscripts = async () => {
    const res = await fetch(
      userId
        ? `/api/avatar/get-transcripts?userId=${userId}`
        : "/api/avatar/get-transcripts",
    );
    const data = await res.json();
    if (!data.success) throw new Error("Failed to fetch transcripts");
    return data.transcripts;
  };

  const { isLoading: loading, data } = useQuery({
    queryKey: userId
      ? ["/avatar/get-transcripts", userId]
      : ["/avatar/get-transcripts"],
    queryFn: fetchTranscripts,
    enabled: !!user?.id,
  });

  if (loading) {
    return (
      <div className="flex justify-center p-8">
        <LoadingSpinner className="mr-2" />
        <span>Loading session results...</span>
      </div>
    );
  }

  if (!data?.length) {
    return (
      <div className="text-center py-12">
        <div className="bg-gray-50 rounded-2xl p-8 max-w-md mx-auto">
          <Target className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-semibold mb-2">No Practice Sessions Yet</h3>
          <p className="text-gray-600 mb-4">
            Start practicing your communication skills to see results here.
          </p>
          <Link to="/avatar/practice">
            <Button>Start First Session</Button>
          </Link>
        </div>
      </div>
    );
  }

  // Filter data based on search term and selected skill
  const filteredData = data.filter((item: TranscriptData) => {
    const matchesSearch = !searchTerm || 
      item.skill_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.scenario_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.context?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesSkill = !selectedSkill || item.skill_name === selectedSkill;
    
    return matchesSearch && matchesSkill;
  });

  // Group transcripts by time periods and skill areas
  const groupedTranscripts: GroupedTranscripts = filteredData.reduce((acc: GroupedTranscripts, transcript: TranscriptData) => {
    const timeGroup = getTimeGroup(transcript.created_at);
    const skillArea = transcript.skill_name || "General Practice";
    
    if (!acc[timeGroup]) acc[timeGroup] = {};
    if (!acc[timeGroup][skillArea]) acc[timeGroup][skillArea] = [];
    
    acc[timeGroup][skillArea].push(transcript);
    return acc;
  }, {});

  // Calculate stats
  const totalSessions = filteredData.length;
  const totalDuration = filteredData.reduce((sum: number, item: TranscriptData) => sum + (Number(item.duration) || 0), 0);
  const totalMessages = filteredData.reduce((sum: number, item: TranscriptData) => sum + (Number(item.message_count) || 0), 0);
  const uniqueSkills = new Set(filteredData.map((item: TranscriptData) => item.skill_name).filter(Boolean)).size;
  const avgDuration = totalSessions > 0 ? Math.round(totalDuration / totalSessions) : 0;

  const timeGroupOrder = ["Today", "Yesterday", "This Week", "This Month", "Older"];

  return (
    <div className="space-y-6">
      {/* Stats Overview */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4 text-blue-600" />
              <div>
                <p className="text-2xl font-bold">{totalSessions}</p>
                <p className="text-xs text-gray-600">Total Sessions</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4 text-green-600" />
              <div>
                <p className="text-2xl font-bold">{Math.round(totalDuration / 60)}m</p>
                <p className="text-xs text-gray-600">Practice Time</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <MessageCircle className="h-4 w-4 text-purple-600" />
              <div>
                <p className="text-2xl font-bold">{totalMessages}</p>
                <p className="text-xs text-gray-600">Conversations</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Target className="h-4 w-4 text-orange-600" />
              <div>
                <p className="text-2xl font-bold">{uniqueSkills}</p>
                <p className="text-xs text-gray-600">Skills Practiced</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-teal-600" />
              <div>
                <p className="text-2xl font-bold">{formatDuration(avgDuration)}</p>
                <p className="text-xs text-gray-600">Avg Duration</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Grouped Session Results */}
      {timeGroupOrder.map((timeGroup) => {
        if (!groupedTranscripts[timeGroup]) return null;
        
        const skillAreas = Object.keys(groupedTranscripts[timeGroup]);
        const sessionCount = skillAreas.reduce((sum, skill) => 
          sum + groupedTranscripts[timeGroup][skill].length, 0
        );

        return (
          <div key={timeGroup} className="space-y-4">
            <div className="flex items-center gap-3">
              <Calendar className="h-5 w-5 text-gray-600" />
              <h2 className="text-xl font-semibold">{timeGroup}</h2>
              <Badge variant="secondary">{sessionCount} session{sessionCount !== 1 ? 's' : ''}</Badge>
            </div>
            
            {skillAreas.map((skillArea) => {
              const sessions = groupedTranscripts[timeGroup][skillArea];
              
              return (
                <div key={`${timeGroup}-${skillArea}`} className="ml-8">
                  <div className="flex items-center gap-2 mb-3">
                    <Badge className={getSkillColor(skillArea)}>{skillArea}</Badge>
                    <span className="text-sm text-gray-500">
                      {sessions.length} session{sessions.length !== 1 ? 's' : ''}
                    </span>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {sessions.map((session: TranscriptData) => (
                      <Card key={session.id} className="hover:shadow-lg transition-shadow">
                        <CardHeader className="pb-3">
                          <div className="flex items-start justify-between">
                            <CardTitle className="text-sm font-medium line-clamp-2">
                              {session.scenario_name || "Practice Session"}
                            </CardTitle>
                            <div className="flex items-center gap-1 text-xs text-gray-500">
                              <Clock className="h-3 w-3" />
                              {formatDuration(session.duration || 0)}
                            </div>
                          </div>
                        </CardHeader>
                        
                        <CardContent className="py-2">
                          <p className="text-sm text-gray-600 line-clamp-3 mb-3">
                            {session.scenario_context || session.context}
                          </p>
                          
                          <div className="flex items-center justify-between text-xs text-gray-500 mb-2">
                            <div className="flex items-center gap-1">
                              <MessageCircle className="h-3 w-3" />
                              {session.message_count || 0} messages
                            </div>
                            <div className="flex items-center gap-1">
                              <User className="h-3 w-3" />
                              {session.avatar_id?.split('_')[0] || 'Avatar'}
                            </div>
                          </div>
                          
                          <div className="text-xs text-gray-400">
                            {format(new Date(session.created_at), 'MMM d, h:mm a')}
                          </div>
                        </CardContent>
                        
                        <CardFooter className="pt-3">
                          <Link
                            to={
                              user?.userType === "coach"
                                ? `/coach-dashboard?tab=avatar&id=${session.id}`
                                : `/avatar/session-analysis/?tid=${session.id}`
                            }
                            className="w-full"
                          >
                            <Button className="w-full" size="sm">
                              View Analysis
                            </Button>
                          </Link>
                        </CardFooter>
                      </Card>
                    ))}
                  </div>
                </div>
              );
            })}
            
            {timeGroup !== "Older" && <Separator />}
          </div>
        );
      })}
    </div>
  );
};