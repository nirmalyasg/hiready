import { useState, useEffect } from "react";
import { Search, Filter, ChevronRight, Sparkles, Target, Zap, MessageSquare, Users, Briefcase } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import ModernDashboardLayout from "@/components/layout/modern-dashboard-layout";
import { useQuery } from "@tanstack/react-query";
import { LoadingSpinner } from "@/components/ui/loading-spinner";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const getScenarioImage = (scenarioName: string): string => {
  const imageMap: { [key: string]: string } = {
    "Addressing Team Concerns": "/images/scenarios/addressing-team-concerns.png",
    "Addressing a Denied Salary or Promotion Request": "/images/scenarios/addressing-denied-salary.png",
    "Addressing a Peer Who Frequently Misses Team Deadlines": "/images/scenarios/missing-team-deadlines.png",
    "Asking for Support or Backup During a Busy Period": "/images/scenarios/teammate-collaboration.png",
    "Collaborating on a Cross-Functional Project with Tight Deadlines": "/images/scenarios/cross-functional-project.png",
    "Asking for Accommodations": "/images/scenarios/workplace-accommodations.png",
    "Clarifying Leave Policies or Compensation Structures": "/images/scenarios/leave-policies.png",
    "Clarifying Miscommunication in a One-on-One Meeting": "/images/scenarios/one-on-one-meeting.png",
    "Asking for Support During a Busy Period": "/images/scenarios/workplace-support.png",
  };
  return imageMap[scenarioName] || "/images/scenarios/default-scenario.png";
};

const scenarioIcons = [
  { icon: MessageSquare, color: "text-blue-500", bg: "bg-blue-100" },
  { icon: Target, color: "text-purple-500", bg: "bg-purple-100" },
  { icon: Zap, color: "text-amber-500", bg: "bg-amber-100" },
  { icon: Users, color: "text-green-500", bg: "bg-green-100" },
  { icon: Briefcase, color: "text-rose-500", bg: "bg-rose-100" },
  { icon: Sparkles, color: "text-cyan-500", bg: "bg-cyan-100" },
];

const getDifficultyColor = (difficulty: string) => {
  switch (difficulty?.toUpperCase()) {
    case "BEGINNER":
      return "bg-green-100 text-green-700 border-green-200";
    case "INTERMEDIATE":
      return "bg-amber-100 text-amber-700 border-amber-200";
    case "ADVANCED":
      return "bg-red-100 text-red-700 border-red-200";
    default:
      return "bg-gray-100 text-gray-700 border-gray-200";
  }
};

export default function PracticePage() {
  const [skills, setSkills] = useState<Record<string, any>[]>([]);
  const [scenarios, setScenarios] = useState<Record<string, any>[]>([]);
  const [filteredScenarios, setFilteredScenarios] = useState<Record<string, any>[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedSkill, setSelectedSkill] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [searchParams] = useSearchParams();
  const skillFilter = searchParams.get("skill");
  const [selectedRole, setSelectedRole] = useState("");
  
  const { data: roles = [], isLoading: rolesLoading } = useQuery({
    queryKey: ["/api/avatar/avatar-roles"],
    queryFn: async () => {
      const res = await fetch("/api/avatar/avatar-roles");
      if (!res.ok) throw new Error("Failed to fetch roles");
      const json = await res.json();
      return json?.data as string[];
    },
  });

  useEffect(() => {
    let mounted = true;
    let controller = new AbortController();

    const fetchData = async () => {
      try {
        setIsLoading(true);
        const params = new URLSearchParams();
        selectedSkill && params.append("skillId", selectedSkill.toString());
        selectedRole && params.append("role", selectedRole.toString());
        
        const [scenariosResponse, skillsResponse] = await Promise.all([
          fetch(`/api/avatar/get-scenarios?${params.toString() || ""}`, {
            signal: controller.signal,
          }),
          fetch("/api/avatar/get-skills", {
            signal: controller.signal,
          }),
        ]);

        const [scenariosData, skillsData] = await Promise.all([
          scenariosResponse.json(),
          skillsResponse.json(),
        ]);

        if (!mounted) return;

        if (scenariosData.success) {
          const normalizedScenarios = scenariosData.scenarios.map((s: any) => ({
            id: s.id,
            skillId: s.skill_id || s.skillId,
            name: s.name,
            description: s.description || "",
            context: s.context || "",
            instructions: s.instructions || "",
            difficulty: s.difficulty || "STANDARD",
            knowledgeId: s.knowledge_id || s.knowledgeId || "",
            image: s.image || "/demo.png",
          }));
          setScenarios(normalizedScenarios);
          setFilteredScenarios(normalizedScenarios);
        }

        if (skillsData.success && skillsData.skills) {
          setSkills(skillsData.skills);
        }
      } catch (error) {
        console.error("Error loading data:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
    return () => {
      mounted = false;
    };
  }, [selectedSkill, selectedRole]);

  useEffect(() => {
    if (skillFilter && skillFilter !== selectedSkill) {
      setSelectedSkill(skillFilter);
    }
  }, [skillFilter]);

  useEffect(() => {
    if (searchQuery.trim()) {
      const filtered = scenarios.filter(
        (s) =>
          s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          s.description.toLowerCase().includes(searchQuery.toLowerCase())
      );
      setFilteredScenarios(filtered);
    } else {
      setFilteredScenarios(scenarios);
    }
  }, [searchQuery, scenarios]);

  const currentSkill = skills.find((skill) => skill.id === selectedSkill);

  const handleSkillFilter = (skillId: string | null) => {
    setSelectedSkill(skillId);
    if (skillId) {
      window.history.pushState({}, "", `/avatar/practice?skill=${skillId}`);
    } else {
      window.history.pushState({}, "", `/avatar/practice`);
    }
  };

  return (
    <ModernDashboardLayout>
      {isLoading || rolesLoading ? (
        <div className="flex justify-center items-center h-screen">
          <LoadingSpinner />
        </div>
      ) : (
        <div className="min-h-screen bg-gray-50/50">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-6 max-w-7xl">
            {/* Header Section */}
            <div className="mb-6">
              <Link
                to="/avatar/dashboard"
                className="inline-flex items-center text-gray-500 hover:text-primary mb-4 text-sm font-medium transition-colors"
                data-testid="link-back-dashboard"
              >
                <ChevronRight className="w-4 h-4 rotate-180 mr-1" />
                Back to Dashboard
              </Link>
              
              <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                <div>
                  <h1 className="text-2xl font-bold text-gray-900" data-testid="text-page-title">
                    {selectedSkill && currentSkill
                      ? `${currentSkill.name} Scenarios`
                      : "Practice Scenarios"}
                  </h1>
                  <p className="text-gray-500 mt-1" data-testid="text-page-subtitle">
                    Choose a scenario to practice with voice-first AI conversations
                  </p>
                </div>

                {/* Search Bar */}
                <div className="relative w-full lg:w-80">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    type="text"
                    placeholder="Search scenarios..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 bg-white border-gray-200"
                    data-testid="input-search-scenarios"
                  />
                </div>
              </div>
            </div>

            {/* Filters Section */}
            <div className="bg-white rounded-xl border border-gray-200 p-4 mb-6 shadow-sm">
              <div className="flex flex-col lg:flex-row lg:items-center gap-4">
                {/* Skill Tabs */}
                <div className="flex-1">
                  <div className="flex flex-wrap gap-2">
                    <button
                      onClick={() => handleSkillFilter(null)}
                      className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                        !selectedSkill
                          ? "bg-primary text-white shadow-sm"
                          : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                      }`}
                      data-testid="button-filter-all"
                    >
                      All ({scenarios.length})
                    </button>
                    {skills.map((skill) => (
                      <button
                        key={skill.id}
                        onClick={() => handleSkillFilter(skill.id)}
                        className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                          selectedSkill === skill.id
                            ? "bg-primary text-white shadow-sm"
                            : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                        }`}
                        data-testid={`button-filter-skill-${skill.id}`}
                      >
                        {skill.name}
                        {skill.scenario_count > 0 && (
                          <span className="ml-1.5 opacity-75">({skill.scenario_count})</span>
                        )}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Role Filter */}
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-2">
                    <Filter className="w-4 h-4 text-gray-400" />
                    <span className="text-sm text-gray-500 font-medium">Role:</span>
                  </div>
                  <Select
                    value={selectedRole || "all"}
                    onValueChange={(v) => setSelectedRole(v === "all" ? "" : v)}
                  >
                    <SelectTrigger className="w-44 bg-white" data-testid="select-role-filter">
                      <SelectValue placeholder="All Roles" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Roles</SelectItem>
                      {roles.map((role) => (
                        <SelectItem key={role} value={role}>
                          {role}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            {/* Results Summary */}
            {filteredScenarios.length > 0 && (
              <div className="mb-4">
                <p className="text-sm text-gray-500">
                  Showing <span className="font-medium text-gray-700">{filteredScenarios.length}</span> scenario{filteredScenarios.length !== 1 ? "s" : ""}
                </p>
              </div>
            )}

            {/* Scenarios Grid */}
            {filteredScenarios.length === 0 ? (
              <div className="text-center py-16 bg-white rounded-xl border border-gray-200">
                <div className="w-20 h-20 mx-auto mb-6 bg-gray-100 rounded-2xl flex items-center justify-center">
                  <MessageSquare className="w-10 h-10 text-gray-400" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  No scenarios found
                </h3>
                <p className="text-gray-500 mb-4 max-w-md mx-auto">
                  {searchQuery
                    ? "Try adjusting your search or filters to find what you're looking for."
                    : "Try selecting a different category or check back later for new scenarios."}
                </p>
                {(selectedSkill || searchQuery) && (
                  <Button
                    variant="outline"
                    onClick={() => {
                      handleSkillFilter(null);
                      setSearchQuery("");
                    }}
                    data-testid="button-clear-filters"
                  >
                    Clear Filters
                  </Button>
                )}
              </div>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {filteredScenarios.map((scenario, index) => {
                  const iconData = scenarioIcons[index % scenarioIcons.length];
                  const IconComponent = iconData.icon;

                  return (
                    <Card
                      key={scenario.id}
                      className="group bg-white border border-gray-200 hover:border-primary/30 hover:shadow-lg transition-all duration-200 overflow-hidden"
                      data-testid={`card-scenario-${scenario.id}`}
                    >
                      <CardContent className="p-0">
                        <div className="flex">
                          {/* Icon Section */}
                          <div className={`w-20 flex-shrink-0 ${iconData.bg} flex items-center justify-center`}>
                            <IconComponent className={`w-8 h-8 ${iconData.color}`} />
                          </div>

                          {/* Content Section */}
                          <div className="flex-1 p-4 flex flex-col min-w-0">
                            <div className="flex items-start justify-between gap-3 mb-2">
                              <h3 className="text-base font-semibold text-gray-900 line-clamp-1 group-hover:text-primary transition-colors">
                                {scenario.name}
                              </h3>
                              <Badge 
                                variant="outline" 
                                className={`flex-shrink-0 text-xs ${getDifficultyColor(scenario.difficulty)}`}
                              >
                                {scenario.difficulty || "Standard"}
                              </Badge>
                            </div>

                            <p className="text-sm text-gray-500 line-clamp-2 mb-3 flex-1">
                              {scenario.description || "Practice this scenario with an AI-powered avatar to improve your communication skills."}
                            </p>

                            <div className="flex items-center justify-between">
                              <span className="text-xs text-gray-400">
                                Voice-First AI Practice
                              </span>
                              <Link
                                to={`/avatar/practice/avatar-select?scenarioId=${scenario.id}`}
                                data-testid={`button-start-scenario-${scenario.id}`}
                              >
                                <Button 
                                  size="sm" 
                                  className="bg-primary hover:bg-primary/90 text-white h-8 px-4 text-sm font-medium"
                                >
                                  Start Voice Practice
                                </Button>
                              </Link>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}
    </ModernDashboardLayout>
  );
}
