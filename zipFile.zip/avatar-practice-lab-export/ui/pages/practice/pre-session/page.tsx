import { useEffect, useState, useRef } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import ModernDashboardLayout from "@/components/layout/modern-dashboard-layout";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useQuery } from "@tanstack/react-query";
import { useAvatarSession } from "@/contexts/AvatarSessionContext";
import { 
  Loader2, 
  CheckCircle2, 
  Sparkles, 
  ChevronLeft, 
  Target, 
  User, 
  MessageSquare, 
  Lightbulb,
  Play,
  Settings2,
  AlertCircle,
  Mic,
  Video,
  Zap,
  Clock,
  Globe
} from "lucide-react";

// Supported languages for avatar conversation
const SUPPORTED_LANGUAGES = [
  { code: "en", name: "English", flag: "🇺🇸" },
  { code: "es", name: "Spanish", flag: "🇪🇸" },
  { code: "fr", name: "French", flag: "🇫🇷" },
  { code: "de", name: "German", flag: "🇩🇪" },
  { code: "it", name: "Italian", flag: "🇮🇹" },
  { code: "pt", name: "Portuguese", flag: "🇵🇹" },
  { code: "zh", name: "Chinese", flag: "🇨🇳" },
  { code: "ja", name: "Japanese", flag: "🇯🇵" },
  { code: "ko", name: "Korean", flag: "🇰🇷" },
  { code: "hi", name: "Hindi", flag: "🇮🇳" },
  { code: "ar", name: "Arabic", flag: "🇸🇦" },
  { code: "ru", name: "Russian", flag: "🇷🇺" },
  { code: "nl", name: "Dutch", flag: "🇳🇱" },
  { code: "pl", name: "Polish", flag: "🇵🇱" },
  { code: "tr", name: "Turkish", flag: "🇹🇷" },
];
import { cn } from "@/lib/utils";

interface Scenario {
  id: string;
  name: string;
  description: string;
  context: string;
  difficulty: string;
  avatarRole?: string;
  instructions?: string;
}

const generateUserObjectives = (scenario: Scenario): string[] => {
  const objectives: string[] = [];
  
  if (scenario.description) {
    objectives.push(`Practice and develop your skills in: ${scenario.description.toLowerCase().replace(/\.$/, '')}`);
  }
  
  if (scenario.avatarRole) {
    objectives.push(`Engage in a realistic conversation with a ${scenario.avatarRole.toLowerCase()}`);
  }
  
  objectives.push("Demonstrate effective communication and active listening");
  objectives.push("Navigate the conversation toward a positive outcome");
  objectives.push("Receive AI-powered feedback on your performance");
  
  return objectives;
};

export default function PreSessionPage() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const scenarioId = searchParams.get("scenarioId");
  const avatarId = searchParams.get("avatarId");
  const [scenario, setScenario] = useState<Scenario | null>(null);
  const [loading, setLoading] = useState(true);
  const [selection, setSelection] = useState<string>(
    "/avatar/roleplay/practice",
  );

  const [selectedPersona, setSelectedPersona] = useState<string | null>(
    searchParams.get("persona") || null,
  );
  const [selectedTone, setSelectedTone] = useState<string | null>(
    searchParams.get("tone") || null,
  );
  const [selectedLanguage, setSelectedLanguage] = useState<string>(
    searchParams.get("language") || "en",
  );

  const avatarSession = useAvatarSession();
  
  async function fetchPersonas(): Promise<string[]> {
    const res = await fetch("/api/avatar/personas");
    const result = await res.json();
    if (!res.ok) throw new Error(result?.error || "Failed to fetch personas");
    if (!result.data) throw new Error("No personas found");
    if (Array.isArray(result.data)) {
      return result.data.map((p: any) => p.persona);
    }
    return result.data;
  }
  
  const { data: personas = [], isLoading: personasLoading } = useQuery({
    queryKey: ["personas"],
    queryFn: fetchPersonas,
  });
  
  async function fetchTones(): Promise<string[]> {
    const res = await fetch("/api/avatar/tones");
    const result = await res.json();
    if (!res.ok) throw new Error(result?.error || "Failed to fetch tones");
    if (!result.data) throw new Error("No tones found");
    if (Array.isArray(result.data)) {
      return result.data.map((t: any) => t.tone);
    }
    return result.data;
  }
  
  const { data: tones = [], isLoading: tonesLoading } = useQuery({
    queryKey: ["tones"],
    queryFn: fetchTones,
  });
  
  useEffect(() => {
    const fetchScenario = async () => {
      try {
        const response = await fetch(
          `/api/avatar/get-scenarios?scenarioId=${scenarioId}`,
        );
        const data = await response.json();
        if (data.scenarios && data.scenarios.length > 0) {
          setScenario(data.scenarios[0]);
        }
      } catch (error) {
        console.error("Error fetching scenario:", error);
      } finally {
        setLoading(false);
      }
    };

    if (scenarioId) {
      fetchScenario();
    }
  }, [scenarioId]);

  const buildKnowledgeBase = () => {
    if (!scenario) return "";
    return `
Context: ${scenario?.context || "Not specified"}
Description: ${scenario?.description || "Not specified"}
Instructions: ${scenario?.instructions || "Not specified"}
${scenario?.avatarRole ? `Role: ${scenario.avatarRole}` : ""}.
${selectedPersona ? `Persona: ${selectedPersona}` : "Helpful virtual assistant"}
${selectedTone ? `Tone: ${selectedTone}` : "Neutral"}

Please be conversational, helpful, and stay in character based on the provided context.
    `.trim();
  };

  const prevConfigRef = useRef<{ persona: string | null; tone: string | null; language: string }>({ persona: null, tone: null, language: "en" });

  useEffect(() => {
    if (
      scenario &&
      avatarId &&
      avatarSession &&
      selection === "/avatar/practice/session"
    ) {
      const knowledgeBase = buildKnowledgeBase();
      const configChanged = 
        prevConfigRef.current.persona !== selectedPersona || 
        prevConfigRef.current.tone !== selectedTone ||
        prevConfigRef.current.language !== selectedLanguage;
      
      if (configChanged && (avatarSession.preWarmedSession?.isReady || avatarSession.isWarming)) {
        console.log("Config changed, restarting warming with new persona/tone/language");
        prevConfigRef.current = { persona: selectedPersona, tone: selectedTone, language: selectedLanguage };
        avatarSession.restartWarming({
          avatarId: avatarId,
          knowledgeBase: knowledgeBase,
          language: selectedLanguage,
        });
      } else if (!avatarSession.preWarmedSession?.isReady && !avatarSession.isWarming) {
        console.log("Pre-warming avatar session for:", avatarId);
        prevConfigRef.current = { persona: selectedPersona, tone: selectedTone, language: selectedLanguage };
        avatarSession.startWarming({
          avatarId: avatarId,
          knowledgeBase: knowledgeBase,
          language: selectedLanguage,
        });
      }
    }
  }, [scenario, avatarId, avatarSession, selection, selectedPersona, selectedTone, selectedLanguage]);

  useEffect(() => {
    return () => {
      if (avatarSession && !avatarSession.preWarmedSession?.isReady) {
        avatarSession.cancelWarming();
      }
    };
  }, []);

  const startSession = () => {
    navigate(
      `${selection}?scenarioId=${scenarioId}&avatarId=${avatarId}&tone=${selectedTone}&persona=${selectedPersona}&language=${selectedLanguage}&autostart=true`,
    );
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty?.toLowerCase()) {
      case 'beginner':
      case 'easy':
        return 'bg-green-100 text-green-700 border-green-200';
      case 'intermediate':
      case 'medium':
        return 'bg-amber-100 text-amber-700 border-amber-200';
      case 'advanced':
      case 'hard':
        return 'bg-red-100 text-red-700 border-red-200';
      default:
        return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  if (loading || personasLoading || tonesLoading) {
    return (
      <ModernDashboardLayout>
        <div className="min-h-screen bg-gray-50/50 flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-lg text-gray-600">Loading scenario details...</p>
          </div>
        </div>
      </ModernDashboardLayout>
    );
  }

  if (!scenario) {
    return (
      <ModernDashboardLayout>
        <div className="min-h-screen bg-gray-50/50 flex items-center justify-center">
          <div className="text-center max-w-md">
            <div className="w-16 h-16 mx-auto mb-6 bg-red-100 rounded-full flex items-center justify-center">
              <AlertCircle className="w-8 h-8 text-red-600" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900 mb-3">
              Scenario Not Found
            </h1>
            <p className="text-gray-600 mb-6">
              The practice scenario you're looking for doesn't exist or may have
              been removed.
            </p>
            <Link to="/avatar/practice">
              <Button size="lg" data-testid="button-return-practice">
                <ChevronLeft className="w-4 h-4 mr-2" />
                Return to Practice
              </Button>
            </Link>
          </div>
        </div>
      </ModernDashboardLayout>
    );
  }

  return (
    <ModernDashboardLayout>
      <div className="min-h-screen bg-gray-50/50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-6 max-w-5xl">
          {/* Header */}
          <div className="mb-6">
            <Link
              to={`/avatar/practice/avatar-select?scenarioId=${scenarioId}`}
              className="inline-flex items-center text-gray-500 hover:text-primary mb-4 text-sm font-medium transition-colors"
              data-testid="link-back-avatar"
            >
              <ChevronLeft className="w-4 h-4 mr-1" />
              Back to Avatar Selection
            </Link>
            <div className="flex items-center gap-3">
              <h1 className="text-2xl lg:text-3xl font-bold text-gray-900" data-testid="text-page-title">
                Session Briefing
              </h1>
              <Badge variant="secondary" className="bg-primary/10 text-primary border-0">
                <Mic className="w-3 h-3 mr-1" />
                Voice-First
              </Badge>
            </div>
            <p className="text-gray-500 mt-1">
              Review the details and choose your practice mode below
            </p>
          </div>

          {/* Main Content Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left Column - Scenario Details */}
            <div className="lg:col-span-2 space-y-5">
              {/* Scenario Overview Card */}
              <Card className="border border-gray-200 shadow-sm overflow-hidden">
                <div className="bg-gradient-to-r from-primary/5 to-primary/10 px-6 py-4 border-b border-gray-100">
                  <div className="flex items-start justify-between">
                    <div>
                      <h2 className="text-xl font-bold text-gray-900" data-testid="text-scenario-name">
                        {scenario.name}
                      </h2>
                      <Badge 
                        variant="outline" 
                        className={`mt-2 ${getDifficultyColor(scenario.difficulty)}`}
                        data-testid="badge-difficulty"
                      >
                        {scenario.difficulty || "Beginner"} Level
                      </Badge>
                    </div>
                    <div className="p-3 bg-white rounded-xl shadow-sm">
                      <Target className="w-6 h-6 text-primary" />
                    </div>
                  </div>
                </div>
                
                <CardContent className="p-6 space-y-5">
                  {/* What You'll Learn */}
                  {scenario.description && (
                    <div data-testid="section-practice">
                      <div className="flex items-center gap-2 mb-3">
                        <div className="p-1.5 bg-blue-100 rounded-lg">
                          <Lightbulb className="w-4 h-4 text-blue-600" />
                        </div>
                        <h3 className="font-semibold text-gray-900">What You'll Learn</h3>
                      </div>
                      <p className="text-gray-600 leading-relaxed pl-9">
                        In this practice session, you will develop skills in <span className="font-medium text-gray-800">{scenario.description.toLowerCase().replace(/\.$/, '')}</span>. You'll receive real-time feedback to help improve your approach.
                      </p>
                    </div>
                  )}

                  {/* The Situation */}
                  {scenario.context && (
                    <div className="bg-amber-50/50 rounded-xl p-4 border border-amber-100" data-testid="section-scenario">
                      <div className="flex items-center gap-2 mb-3">
                        <div className="p-1.5 bg-amber-100 rounded-lg">
                          <MessageSquare className="w-4 h-4 text-amber-600" />
                        </div>
                        <h3 className="font-semibold text-gray-900">The Situation</h3>
                      </div>
                      <p className="text-gray-700 leading-relaxed pl-9">
                        <span className="font-medium text-amber-700">Your scenario:</span> {scenario.context}
                      </p>
                    </div>
                  )}

                  {/* Your Conversation Partner */}
                  {scenario.avatarRole && (
                    <div className="bg-primary/5 rounded-xl p-4 border border-primary/10" data-testid="section-avatar-role">
                      <div className="flex items-center gap-2 mb-3">
                        <div className="p-1.5 bg-primary/20 rounded-lg">
                          <User className="w-4 h-4 text-primary" />
                        </div>
                        <h3 className="font-semibold text-gray-900">Your Conversation Partner</h3>
                      </div>
                      <div className="pl-9">
                        <p className="text-lg font-medium text-primary mb-2">
                          {scenario.avatarRole}
                        </p>
                        <p className="text-gray-600 text-sm leading-relaxed">
                          You'll be speaking with an AI playing this role. They will respond realistically based on the scenario, giving you authentic practice for real-world situations.
                        </p>
                      </div>
                    </div>
                  )}

                  {/* Your Objectives */}
                  <div className="bg-green-50/50 rounded-xl p-4 border border-green-100" data-testid="section-objective">
                    <div className="flex items-center gap-2 mb-3">
                      <div className="p-1.5 bg-green-100 rounded-lg">
                        <Target className="w-4 h-4 text-green-600" />
                      </div>
                      <h3 className="font-semibold text-gray-900">Your Objectives</h3>
                    </div>
                    <ul className="space-y-2 pl-9">
                      {generateUserObjectives(scenario).map((objective, index) => (
                        <li key={index} className="flex items-start gap-2 text-gray-700">
                          <CheckCircle2 className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                          <span className="leading-relaxed">{objective}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Right Column - Session Settings & Start */}
            <div className="space-y-5">
              {/* Practice Mode Selection */}
              <Card className="border border-gray-200 shadow-sm" data-testid="card-mode-selection">
                <div className="px-5 py-4 border-b border-gray-100">
                  <div className="flex items-center gap-2">
                    <Zap className="w-5 h-5 text-primary" />
                    <h3 className="font-semibold text-gray-900">Choose Practice Mode</h3>
                  </div>
                </div>
                <CardContent className="p-4 space-y-3">
                  {/* Voice Mode Card - Default/Recommended */}
                  <button
                    type="button"
                    onClick={() => setSelection("/avatar/roleplay/practice")}
                    className={cn(
                      "w-full p-4 rounded-xl border-2 text-left transition-all duration-200",
                      selection === "/avatar/roleplay/practice"
                        ? "border-primary bg-primary/5 ring-2 ring-primary/20"
                        : "border-gray-200 hover:border-gray-300 hover:bg-gray-50"
                    )}
                    data-testid="mode-voice"
                  >
                    <div className="flex items-start gap-3">
                      <div className={cn(
                        "p-2.5 rounded-xl",
                        selection === "/avatar/roleplay/practice"
                          ? "bg-primary text-white"
                          : "bg-gray-100 text-gray-600"
                      )}>
                        <Mic className="w-5 h-5" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-semibold text-gray-900">Voice Practice</span>
                          <Badge className="bg-green-100 text-green-700 border-0 text-xs px-2 py-0">
                            Recommended
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-500 mt-1">
                          Natural voice conversations with AI
                        </p>
                        <div className="flex items-center gap-3 mt-2">
                          <span className="inline-flex items-center text-xs text-green-600 font-medium">
                            <Zap className="w-3 h-3 mr-1" />
                            Lower credits
                          </span>
                          <span className="inline-flex items-center text-xs text-gray-500">
                            <Clock className="w-3 h-3 mr-1" />
                            Instant start
                          </span>
                        </div>
                      </div>
                      <div className={cn(
                        "w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0",
                        selection === "/avatar/roleplay/practice"
                          ? "border-primary bg-primary"
                          : "border-gray-300"
                      )}>
                        {selection === "/avatar/roleplay/practice" && (
                          <CheckCircle2 className="w-4 h-4 text-white" />
                        )}
                      </div>
                    </div>
                  </button>

                  {/* Video Mode Card - Premium Upgrade */}
                  <button
                    type="button"
                    onClick={() => setSelection("/avatar/practice/session")}
                    className={cn(
                      "w-full p-4 rounded-xl border-2 text-left transition-all duration-200",
                      selection === "/avatar/practice/session"
                        ? "border-primary bg-primary/5 ring-2 ring-primary/20"
                        : "border-gray-200 hover:border-gray-300 hover:bg-gray-50"
                    )}
                    data-testid="mode-video"
                  >
                    <div className="flex items-start gap-3">
                      <div className={cn(
                        "p-2.5 rounded-xl",
                        selection === "/avatar/practice/session"
                          ? "bg-primary text-white"
                          : "bg-gray-100 text-gray-600"
                      )}>
                        <Video className="w-5 h-5" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-semibold text-gray-900">Video Avatar</span>
                          <Badge variant="outline" className="text-xs px-2 py-0 border-amber-300 text-amber-700 bg-amber-50">
                            Premium
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-500 mt-1">
                          Full video with realistic AI avatar
                        </p>
                        <div className="flex items-center gap-3 mt-2">
                          <span className="inline-flex items-center text-xs text-amber-600 font-medium">
                            <Zap className="w-3 h-3 mr-1" />
                            Higher credits
                          </span>
                          <span className="inline-flex items-center text-xs text-gray-500">
                            <Clock className="w-3 h-3 mr-1" />
                            ~3-5s warm-up
                          </span>
                        </div>
                      </div>
                      <div className={cn(
                        "w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0",
                        selection === "/avatar/practice/session"
                          ? "border-primary bg-primary"
                          : "border-gray-300"
                      )}>
                        {selection === "/avatar/practice/session" && (
                          <CheckCircle2 className="w-4 h-4 text-white" />
                        )}
                      </div>
                    </div>
                  </button>

                  {/* Info Banner */}
                  <div className="bg-blue-50 rounded-lg p-3 border border-blue-100">
                    <p className="text-xs text-blue-700">
                      <strong>Tip:</strong> Voice mode is faster and uses fewer credits. Upgrade to video when you want the full visual experience.
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* Customize Session Card */}
              <Card className="border border-gray-200 shadow-sm" data-testid="card-settings">
                <div className="px-5 py-4 border-b border-gray-100">
                  <div className="flex items-center gap-2">
                    <Settings2 className="w-5 h-5 text-gray-400" />
                    <h3 className="font-semibold text-gray-900">Customize Avatar</h3>
                  </div>
                </div>
                <CardContent className="p-5 space-y-4">
                  {/* Tone Selection */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Avatar Tone
                    </label>
                    <Select
                      value={selectedTone || ""}
                      onValueChange={setSelectedTone}
                    >
                      <SelectTrigger className="w-full bg-white" data-testid="select-tone">
                        <SelectValue placeholder="Select a tone..." />
                      </SelectTrigger>
                      <SelectContent>
                        {tones.map((t) => (
                          <SelectItem key={t} value={t}>
                            {t}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-gray-500 mt-1.5">
                      How the avatar will communicate with you
                    </p>
                  </div>

                  {/* Persona Selection */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Avatar Persona
                    </label>
                    <Select
                      value={selectedPersona || ""}
                      onValueChange={setSelectedPersona}
                    >
                      <SelectTrigger className="w-full bg-white" data-testid="select-persona">
                        <SelectValue placeholder="Select a persona..." />
                      </SelectTrigger>
                      <SelectContent>
                        {personas.map((p) => (
                          <SelectItem key={p} value={p}>
                            {p}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-gray-500 mt-1.5">
                      The personality style of the avatar
                    </p>
                  </div>

                  {/* Language Selection */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      <div className="flex items-center gap-2">
                        <Globe className="w-4 h-4 text-gray-500" />
                        Conversation Language
                      </div>
                    </label>
                    <Select
                      value={selectedLanguage}
                      onValueChange={setSelectedLanguage}
                    >
                      <SelectTrigger className="w-full bg-white" data-testid="select-language">
                        <SelectValue placeholder="Select a language..." />
                      </SelectTrigger>
                      <SelectContent>
                        {SUPPORTED_LANGUAGES.map((lang) => (
                          <SelectItem key={lang.code} value={lang.code}>
                            <span className="flex items-center gap-2">
                              <span>{lang.flag}</span>
                              <span>{lang.name}</span>
                            </span>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-gray-500 mt-1.5">
                      The avatar will speak and understand this language
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* Start Session Card */}
              <Card className="border-2 border-primary/20 shadow-sm bg-gradient-to-br from-primary/5 to-white" data-testid="card-start-session">
                <CardContent className="p-5">
                  <div className="text-center mb-4">
                    <h3 className="font-semibold text-gray-900 mb-1">Ready to Begin?</h3>
                    <p className="text-sm text-gray-500">
                      {selection === "/avatar/roleplay/practice" 
                        ? "Voice session starts instantly" 
                        : "Video avatar will connect shortly"}
                    </p>
                  </div>

                  <Button
                    size="lg"
                    onClick={startSession}
                    className="w-full py-6 text-base font-semibold bg-primary hover:bg-primary/90"
                    data-testid="button-start-session"
                  >
                    {selection === "/avatar/roleplay/practice" ? (
                      <>
                        <Mic className="w-5 h-5 mr-2" />
                        Start Voice Practice
                      </>
                    ) : (
                      <>
                        <Video className="w-5 h-5 mr-2" />
                        Start Video Session
                      </>
                    )}
                  </Button>

                  {/* Mode-specific status */}
                  {selection === "/avatar/roleplay/practice" ? (
                    <div className="mt-4 flex items-center justify-center gap-2 text-sm">
                      <CheckCircle2 className="w-4 h-4 text-green-500" />
                      <span className="text-green-600 text-xs">Voice connects instantly</span>
                    </div>
                  ) : avatarSession && (
                    <div className="mt-4 flex items-center justify-center gap-2 text-sm">
                      {avatarSession.isWarming ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin text-primary" />
                          <span className="text-gray-600">{avatarSession.warmingStatus}</span>
                          {avatarSession.warmingProgress > 0 && (
                            <span className="text-gray-400">({avatarSession.warmingProgress}%)</span>
                          )}
                        </>
                      ) : avatarSession.preWarmedSession?.isReady ? (
                        <>
                          <CheckCircle2 className="w-4 h-4 text-green-500" />
                          <span className="text-green-600 text-xs">Video avatar ready</span>
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-4 h-4 text-primary/60" />
                          <span className="text-gray-500 text-xs">
                            {avatarSession.warmingStatus === "Will connect on start" || avatarSession.warmingStatus === "Server busy, retrying..." 
                              ? avatarSession.warmingStatus 
                              : "Video avatar will connect on start"}
                          </span>
                        </>
                      )}
                    </div>
                  )}

                  <p className="text-xs text-center text-gray-400 mt-4">
                    Take your time — there's no wrong answer
                  </p>
                </CardContent>
              </Card>

              {/* Tips Card */}
              <Card className="border border-gray-200 shadow-sm bg-gray-50/50">
                <CardContent className="p-4">
                  <h4 className="font-medium text-gray-900 text-sm mb-2">Quick Tips</h4>
                  <ul className="text-xs text-gray-600 space-y-1.5">
                    <li className="flex items-start gap-2">
                      <span className="text-primary mt-0.5">•</span>
                      <span>Speak naturally as you would in a real conversation</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-primary mt-0.5">•</span>
                      <span>Listen actively and respond to what the avatar says</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-primary mt-0.5">•</span>
                      <span>You can end the session at any time</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </ModernDashboardLayout>
  );
}
