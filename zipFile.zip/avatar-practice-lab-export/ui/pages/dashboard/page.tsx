import { useState, useEffect } from "react";
import {
  Clock,
  Users,
  Trophy,
  ArrowRight,
  Briefcase,
  Handshake,
  MessageSquare,
  UserPlus,
  Video,
  Award,
  BarChart3,
  Target,
  Brain,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Spinner } from "@/components/ui/spinner";
import { Progress } from "@/components/ui/progress";
import { Link } from "react-router-dom";
import ModernDashboardLayout from "@/components/layout/modern-dashboard-layout";
import { useQuery } from "@tanstack/react-query";

interface Skill {
  id: string;
  name: string;
  description: string;
  scenario_count: number;
}

interface Transcript {
  id: string;
  skill_id: string;
  knowledge_id: string;
  streaming_sessions: any[];
  messages: any[];
  created_at: string;
}

interface DashboardStats {
  totalTime: string;
  completedScenarios: number;
  skillProgress: number;
  averageSessionDuration: string;
  uniqueSkillsPracticed: number;
  totalSessions: number;
  lastSessionDate: string;
  skillBreakdown: Record<string, number>;
}

export default function AvatarSimulatorDashboard() {
  const [skills, setSkills] = useState<Skill[]>([]);
  const [stats, setStats] = useState<DashboardStats>({
    totalTime: "0h 0m",
    completedScenarios: 0,
    skillProgress: 0,
    averageSessionDuration: "0m",
    uniqueSkillsPracticed: 0,
    totalSessions: 0,
    lastSessionDate: "-",
    skillBreakdown: {},
  });
  const [isLoading, setIsLoading] = useState(true);
  const fetchSkills = async () => {
    const res = await fetch("/api/avatar/get-skills");
    const data = await res.json();
    if (!data.success) throw new Error("Failed to fetch skills");
    return data.skills;
  };

  const fetchTranscripts = async () => {
    const res = await fetch("/api/avatar/get-transcripts");
    const data = await res.json();
    if (!data.success) throw new Error("Failed to fetch transcripts");
    return data.transcripts;
  };
  const skillsQuery = useQuery({
    queryKey: ["/avatar/get-skills"],
    queryFn: fetchSkills,
  });

  const transcriptsQuery = useQuery({
    queryKey: ["/avatar/get-transcripts"],
    queryFn: fetchTranscripts,
    enabled: !!skillsQuery.data,
  });

  useEffect(() => {
    if (skillsQuery.data) {
      setSkills(skillsQuery.data);
    }
  }, [skillsQuery.data]);

  useEffect(() => {
    if (transcriptsQuery.data && skillsQuery.data) {
      const transcripts = transcriptsQuery.data;

      const skillOccurrences: Record<string, number> = {};
      const uniqueScenarios = new Set();
      const skillMap = new Map();
      let totalDuration = 0;
      let completedSessionsCount = 0;

      transcripts.forEach((transcript) => {
        if (transcript.knowledge_id) {
          uniqueScenarios.add(transcript.knowledge_id);
        }

        if (transcript.skill_id) {
          skillMap.set(transcript.skill_id, true);
          skillOccurrences[transcript.skill_id] =
            (skillOccurrences[transcript.skill_id] || 0) + 1;
        }

        if (
          transcript.streaming_sessions &&
          Array.isArray(transcript.streaming_sessions)
        ) {
          transcript.streaming_sessions.forEach((session) => {
            const duration = parseInt(session.duration);
            if (!isNaN(duration)) {
              totalDuration += duration;
              completedSessionsCount++;
            }
          });
        }
      });

      const hours = Math.floor(totalDuration / 60);
      const minutes = totalDuration % 60;
      const avgDuration = transcripts.length
        ? Math.round(totalDuration / transcripts.length)
        : 0;

      const lastSession = transcripts[0]?.created_at
        ? new Date(transcripts[0].created_at).toLocaleDateString()
        : "-";

      setStats({
        totalTime: `${hours}h ${minutes}m`,
        completedScenarios: uniqueScenarios.size,
        skillProgress:
          skillsQuery.data.length > 0
            ? Math.min(
                Math.round((skillMap.size / skillsQuery.data.length) * 100),
                100,
              )
            : 0,
        averageSessionDuration: `${avgDuration}m`,
        uniqueSkillsPracticed: skillMap.size,
        totalSessions: completedSessionsCount,
        lastSessionDate: lastSession,
        skillBreakdown: skillOccurrences,
      });

      setIsLoading(false);
    }
  }, [transcriptsQuery.data, skillsQuery.data]);

  const getSkillIcon = (skillName: string) => {
    const icons: Record<string, any> = {
      "Business Communication": Briefcase,
      "Team Collaboration": Users,
      "Public Speaking": MessageSquare,
      Negotiation: Handshake,
      "Conflict Resolution": UserPlus,
      "Job Interviews": Video,
    };
    return icons[skillName] || Trophy;
  };

  if (isLoading) {
    return (
      <>
        <div className="flex justify-center items-center h-screen">
          <Spinner size="lg" />
        </div>
      </>
    );
  }

  return (
    <>
      <div className="p-8 max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-2xl font-bold mb-2">Practice Dashboard</h1>
            <p className="text-gray-600">
              Track your communication skills progress
            </p>
          </div>
          <Link to="/avatar/practice">
            <Button color="primary" className="px-6" data-testid="button-start-voice-practice">
              Start Voice Practice
            </Button>
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Card className="p-6 bg-[--card-background] text-[--card-foreground]">
            <div className="flex items-center gap-4">
              <Clock className="w-8 h-8 text-blue-500" />
              <div>
                <p className="text-sm text-gray-600">Total Practice Time</p>
                <p className="text-2xl font-bold">{stats.totalTime}</p>
              </div>
            </div>
          </Card>

          <Card className="p-6 bg-[--card-background] text-[--card-foreground]">
            <div className="flex items-center gap-4">
              <Target className="w-8 h-8 text-green-500" />
              <div>
                <p className="text-sm text-gray-600">Scenarios Completed</p>
                <p className="text-2xl font-bold">{stats.completedScenarios}</p>
              </div>
            </div>
          </Card>

          <Card className="p-6 bg-[--card-background] text-[--card-foreground]">
            <div className="flex items-center gap-4">
              <Brain className="w-8 h-8 text-purple-500" />
              <div>
                <p className="text-sm text-gray-600">Skills Practiced</p>
                <p className="text-2xl font-bold">
                  {stats.uniqueSkillsPracticed}
                </p>
              </div>
            </div>
          </Card>

          <Card className="p-6 bg-[--card-background] text-[--card-foreground]">
            <div className="flex items-center gap-4">
              <BarChart3 className="w-8 h-8 text-orange-500" />
              <div>
                <p className="text-sm text-gray-600">Total Sessions</p>
                <p className="text-2xl font-bold">{stats.totalSessions}</p>
              </div>
            </div>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <Card className="p-6">
            <h3 className="text-xl font-semibold mb-4">Skill Progress</h3>
            <div className="space-y-4">
              {skills.map((skill) => {
                const practiceCount = stats.skillBreakdown[skill.id] || 0;
                return (
                  <div key={skill.id}>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm font-medium">{skill.name}</span>
                      <span className="text-sm text-gray-600">
                        {practiceCount} sessions
                      </span>
                    </div>
                    <Progress
                      value={practiceCount}
                      max={10} // Benchmark: 10 successful sessions considered mastery
                      color={practiceCount >= 10 ? "success" : "primary"}
                      className="h-2"
                    />
                  </div>
                );
              })}
            </div>
          </Card>

          <Card className="p-6">
            <h3 className="text-xl font-semibold mb-4">Recent Activity</h3>
            <div className="space-y-4">
              <div className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
                <div>
                  <p className="text-sm text-gray-600">Last Practice Session</p>
                  <p className="font-medium">{stats.lastSessionDate}</p>
                </div>
              </div>
              <div className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
                <div>
                  <p className="text-sm text-gray-600">
                    Average Session Duration
                  </p>
                  <p className="font-medium">{stats.averageSessionDuration}</p>
                </div>
              </div>
              <div className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
                <div>
                  <p className="text-sm text-gray-600">Overall Progress</p>
                  <p className="font-medium">
                    {stats.skillProgress}% of skills explored
                  </p>
                </div>
              </div>
            </div>
          </Card>
        </div>

        <div>
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-semibold">Available Skills</h2>
            <Link
              to="/avatar/practice"
              className="text-sm text-blue-500 hover:text-blue-700"
            >
              View All
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {skills.map((skill) => {
              const Icon = getSkillIcon(skill.name);
              return (
                <Link key={skill.id} to={`/avatar/practice?skill=${skill.id}`}>
                  <Card className="p-4 hover:scale-[1.02] transition-transform cursor-pointer">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="p-2 rounded-lg bg-gray-100">
                          <Icon className="w-6 h-6" />
                        </div>
                        <div>
                          <h3 className="font-medium">{skill.name}</h3>
                          <p className="text-sm text-gray-500">
                            {skill.scenario_count} scenarios
                          </p>
                        </div>
                      </div>
                      <ArrowRight className="w-5 h-5 text-gray-400" />
                    </div>
                  </Card>
                </Link>
              );
            })}
          </div>
        </div>
      </div>
    </>
  );
}
