import React, { useEffect, useRef, useState } from "react";
import {
  useSearchParams,
  useLocation,
  useNavigate,
  Link,
} from "react-router-dom";
import { v4 as uuidv4 } from "uuid";

// UI components
import Transcript from "@/components/avatar-roleplay/Transcript";
import BottomToolbar from "@/components/avatar-roleplay/BottomToolbar";

// Types
import { SessionStatus } from "../../../types/avatar-roleplay-types";
import type { RealtimeAgent } from "@openai/agents/realtime";
import { useReactMediaRecorder } from "react-media-recorder";

// Context providers & hooks
import { useTranscript } from "../../../contexts/TranscriptContext";
import { useEvent } from "../../../contexts/EventContext";
import { useRealtimeSession } from "@/hooks/useRealtimeSession";
import { useAvatarById } from "@/hooks/use-avatars";
import { createModerationGuardrail } from "../../../lib/avatarRoleplayAgentConfigs/guardrails";
import { TranscriptProvider } from "../../../contexts/TranscriptContext";
import { EventProvider } from "../../../contexts/EventContext";
// Agent configs
import {
  chatRoleplayScenario,
  createRealtimeAgent,
} from "../../../lib/avatarRoleplayAgentConfigs/roleplay";
import { chatPlatformName } from "../../../lib/avatarRoleplayAgentConfigs/roleplay";
// import { getNextResponseFromSupervisor } from "./supervisorAgent";
// import { avatarData } from "../practice/avatar-select/page";
import useAudioDownload from "@/hooks/useAudioDownload";
import { useHandleSessionHistory } from "@/hooks/useHandleSessionHistory";
import { SCENARIOS } from "./roleplay-scenarios-page";
import ModernDashboardLayout from "@/components/layout/modern-dashboard-layout";
import { useAuth } from "@/hooks/use-auth";
import { Globe } from "lucide-react";

const languageNames: Record<string, string> = {
  en: "English",
  es: "Spanish",
  fr: "French",
  de: "German",
  it: "Italian",
  pt: "Portuguese",
  zh: "Mandarin",
  ja: "Japanese",
  ko: "Korean",
  hi: "Hindi",
  ar: "Arabic",
  ru: "Russian",
  nl: "Dutch",
  pl: "Polish",
  tr: "Turkish",
};
function AvatarRoleplayPracticePage() {
  return (
    <TranscriptProvider>
      <EventProvider>
        <AvatarRoleplayPractice />
      </EventProvider>
    </TranscriptProvider>
  );
}

export default AvatarRoleplayPracticePage;
const AvatarRoleplayPractice = () => {
  const { user } = useAuth();
  const location = useLocation();
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const [scenario, setScenario] = useState(null);
  const [error, setError] = useState("");
  const avatarId = searchParams.get("avatarId");
  const { data: avatarData, isLoading } = useAvatarById(avatarId);
  // const { status, startRecording, stopRecording, mediaBlobUrl:audioUrl } =useReactMediaRecorder({ audio: true });
  // const downloadRecording = async () => {
  //   if (!mediaBlobUrl) return;

  //   const response = await fetch(mediaBlobUrl);
  //   const blob = await response.blob();

  //   // Create a temporary link
  //   const url = URL.createObjectURL(blob);
  //   const a = document.createElement("a");
  //   a.style.display = "none";
  //   a.href = url;
  //   a.download = "recording.mp3"; // change extension to .wav if needed
  //   document.body.appendChild(a);
  //   a.click();

  //   // Cleanup
  //   URL.revokeObjectURL(url);
  //   document.body.removeChild(a);
  // };
  // ---------------------------------------------------------------------
  // Codec selector – lets you toggle between wide-band Opus (48 kHz)
  // and narrow-band PCMU/PCMA (8 kHz) to hear what the agent sounds like on
  // a traditional phone line and to validate ASR / VAD behaviour under that
  // constraint.
  //
  // We read the `?codec=` query-param and rely on the `changePeerConnection`
  // hook (configured in `useRealtimeSession`) to set the preferred codec
  // before the offer/answer negotiation.
  // ---------------------------------------------------------------------
  const urlCodec = searchParams.get("codec") || "opus";
  // Agents SDK doesn't currently support codec selection so it is now forced
  // via global codecPatch at module load

  const { transcriptItems, addTranscriptMessage, addTranscriptBreadcrumb } =
    useTranscript();
  const { logClientEvent, logServerEvent } = useEvent();
  const [isInitializing, setIsInitializing] = useState(true);

  const [selectedAgentName, setSelectedAgentName] =
    useState<string>("chatRoleplay");
  // const [selectedAgentConfigSet, setSelectedAgentConfigSet] = useState<
  //   RealtimeAgent[] | null
  // >(sdkScenarioMap.chatSupervisor);

  const audioElementRef = useRef<HTMLAudioElement | null>(null);
  // Ref to identify whether the latest agent switch came from an automatic handoff
  // const handoffTriggeredRef = useRef(false);

  const sdkAudioElement = React.useMemo(() => {
    if (typeof window === "undefined") return undefined;
    const el = document.createElement("audio");
    el.autoplay = true;
    el.style.display = "none";
    document.body.appendChild(el);
    return el;
  }, []);
  const scenarioId = searchParams.get("scenarioId");

  useEffect(() => {
    if (user && !user?.isAIAvatarEnabled) {
      navigate("/dashboard");
      return;
    }
    const fetchScenario = async () => {
      try {
        setIsInitializing(true);
        const response = await fetch(
          `/api/avatar/get-scenarios?scenarioId=${scenarioId}`,
        );
        const data = await response.json();
        if (data.scenarios && data.scenarios.length > 0) {
          setScenario(data.scenarios[0]);
          console.log("scenario", data.scenarios[0]);
          if (data.scenarios[0].skillId) {
            const newParams = new URLSearchParams(searchParams);
            newParams.set("skill", data.scenarios[0].skillId);
            setSearchParams(newParams);
          }
        } else {
          setError(
            "Scenario not found. Please return to practice and try again.",
          );
        }
      } catch (error) {
        console.error("Error fetching scenario:", error);
        setError(
          "Unable to load the practice scenario. Please check your connection and try again.",
        );
      } finally {
        setIsInitializing(false);
      }
    };

    if (scenarioId) {
      fetchScenario();
    } else {
      setIsInitializing(false);
    }
  }, [scenarioId, user]);
  // Attach SDK audio element once it exists (after first render in browser)
  useEffect(() => {
    if (sdkAudioElement && !audioElementRef.current) {
      audioElementRef.current = sdkAudioElement;
    }
  }, [sdkAudioElement]);

  const { connect, disconnect, sendUserText, sendEvent, interrupt, mute } =
    useRealtimeSession({
      onConnectionChange: (s) => setSessionStatus(s as SessionStatus),
      // onAgentHandoff: (agentName: string) => {
      //   handoffTriggeredRef.current = true;
      //   setSelectedAgentName(agentName);
      // },
    });

  const [sessionStatus, setSessionStatus] =
    useState<SessionStatus>("DISCONNECTED");

  const [isEventsPaneExpanded, setIsEventsPaneExpanded] =
    useState<boolean>(false);
  const [userText, setUserText] = useState<string>("");
  const [isPTTActive, setIsPTTActive] = useState<boolean>(false);
  const [isPTTUserSpeaking, setIsPTTUserSpeaking] = useState<boolean>(false);
  const [isAudioPlaybackEnabled, setIsAudioPlaybackEnabled] = useState<boolean>(
    () => {
      if (typeof window === "undefined") return true;
      const stored = localStorage.getItem("audioPlaybackEnabled");
      return stored ? stored === "true" : true;
    },
  );

  // Initialize the recording hook.
  const {
    startRecording,
    stopRecording,
    downloadRecording,
    generatePlaybackUrl,
    audioUrl,
    generateBlob,
  } = useAudioDownload();

  console.log({ audioUrl });
  const sendClientEvent = (eventObj: any, eventNameSuffix = "") => {
    try {
      sendEvent(eventObj);
      logClientEvent(eventObj, eventNameSuffix);
    } catch (err) {
      console.error("Failed to send via SDK", err);
    }
  };

  useHandleSessionHistory();

  useEffect(() => {
    if (isInitializing) return;
    if (selectedAgentName && sessionStatus === "DISCONNECTED") {
      connectToRealtime();
    }
  }, [selectedAgentName, isInitializing]);
  // useEffect(() => {
  //   if (!transcriptItems?.length) return;

  //   // Listen to transcript items; whenever a new agent message is DONE
  //   const lastAgentMessage = transcriptItems
  //     .filter((i) => i.status === "DONE" && i.role !== "user")
  //     .slice(-1)[0];

  //   if (!lastAgentMessage) return;

  //   // Generate playback URL for user to listen
  //   generatePlaybackUrl();
  // }, [transcriptItems]);

  // useEffect(() => {
  //   if (
  //     sessionStatus === "CONNECTED" &&
  //     selectedAgentConfigSet &&
  //     selectedAgentName
  //   ) {
  //     // const currentAgent = selectedAgentConfigSet.find(
  //     //   (a) => a.name === selectedAgentName
  //     // );
  //     // addTranscriptBreadcrumb(`Agent: ${selectedAgentName}`, currentAgent);
  //     // updateSession(!handoffTriggeredRef.current);
  //     // Reset flag after handling so subsequent effects behave normally
  //     handoffTriggeredRef.current = false;
  //   }
  // }, [selectedAgentConfigSet, selectedAgentName, sessionStatus]);

  useEffect(() => {
    if (sessionStatus === "CONNECTED") {
      updateSession(!!!transcriptItems?.length);
    }
  }, [isPTTActive, isInitializing, sessionStatus]);

  const fetchEphemeralKey = async (): Promise<string | null> => {
    logClientEvent({ url: "/session" }, "fetch_session_token_request");
    const tokenResponse = await fetch("/api/avatar/session");
    const data = await tokenResponse.json();
    logServerEvent(data, "fetch_session_token_response");

    if (!data.client_secret?.value) {
      logClientEvent(data, "error.no_ephemeral_key");
      console.error("No ephemeral key provided by the server");
      setSessionStatus("DISCONNECTED");
      return null;
    }

    return data.client_secret.value;
  };
  const voiceMap: Record<string, string> = {
    male: "ballad",
    female: "sage",
  };

  function getApiVoice(gender: string) {
    if (!gender) return "sage";
    return voiceMap[gender.toLowerCase()] || "sage";
  }
  const toneFromParams = searchParams.get("tone") || "";
  const languageFromParams = searchParams.get("language") || "en";
  function formExtraContext(
    learnerName: string,
    scenario: {
      name?: string;
      instructions?: string;
      context?: string;
      description?: string;
      avatarRole?: string;
      avatarName?: string;
    },
  ) {
    return `
## IMPORTANT: Role Assignment
- YOU are playing: ${scenario?.avatarName || "the stakeholder"} (${scenario?.avatarRole || "stakeholder"})
- The USER is playing: ${learnerName || "the manager/professional"} who is practicing their skills
- Stay in character as ${scenario?.avatarName || "the stakeholder"} throughout the conversation
- The user is the one practicing - they should lead and you should respond as ${scenario?.avatarName || "your character"}

${scenario?.name ? `## Scenario: ${scenario.name}` : ""}
${scenario?.description ? `## Situation Overview\n${scenario.description}` : ""}
${scenario?.context ? `## Your Character's Mindset & Behavior\n${scenario.context}` : ""}
${scenario?.instructions ? `## How to Play Your Character\n${scenario.instructions}` : ""}
    `.trim();
  }
  const waitUntilReady = async (delay = 1000) => {
    console.log(`Waiting for ${delay}ms...`);
    await new Promise((resolve) => setTimeout(resolve, delay));
  };
  const buildHistoryContext = () => {
    const filteredItems = transcriptItems?.filter(
      (item) => item.status === "DONE" && !item.isHidden,
    );

    if (!filteredItems || filteredItems.length === 0) return ""; // no history

    const recentItems =
      filteredItems.length > 6 ? filteredItems.slice(-6) : filteredItems;

    return recentItems
      .map(
        (item) =>
          `${item.role === "user" ? "Learner" : "Coach"}: ${item.title}`,
      )
      .join("\n");
  };

  console.log("avatar Data", avatarData);
  const connectToRealtime = async () => {
    if (sessionStatus !== "DISCONNECTED") return;
    setSessionStatus("CONNECTING");
    console.log("isInitializing in connect", isInitializing);
    try {
      if (isInitializing) {
        // await waitUntilReady(500);
        return;
      }

      const EPHEMERAL_KEY = await fetchEphemeralKey();
      if (!EPHEMERAL_KEY) return;
      // const scenarioKey = searchParams.get("scenario") || "";
      // const scenario = SCENARIOS.find((s) => s.key === scenarioKey);
      // console.log("scenario", scenario, "scenarioKey", scenarioKey);
      // const selectedAvatar = avatarData?.find((a) => a?.id === avatarId);
      const selectedAvatar = avatarData;
      const title = scenario?.name || "";
      const notes = formExtraContext(user?.displayName || "", scenario || {});

      const historyContext = buildHistoryContext();

      console.log({ isInitializing }, "notes scenario", notes);
      console.log("selectedAvatar", selectedAvatar);

      const voice = getApiVoice(selectedAvatar?.gender || "");
      console.log("voice", voice);
      const agentInstructions = historyContext
        ? `${notes}\n\n# Previous Conversation\n${historyContext}`
        : notes;
      const role = scenario.avatarRole || "stakeholder";
      const avatarPersona = scenario.avatarName || "the stakeholder";
      const scenarioTone = toneFromParams || "realistic";
      const agent = createRealtimeAgent(
        title,
        agentInstructions,
        voice,
        role,
        avatarPersona,
        scenarioTone,
        languageFromParams,
      );
      // Ensure the selectedAgentName is first so that it becomes the root
      const reorderedAgents = [agent];

      const companyName = chatPlatformName;
      // const guardrail = createModerationGuardrail(companyName);

      await connect({
        getEphemeralKey: async () => EPHEMERAL_KEY,
        initialAgents: reorderedAgents,
        audioElement: sdkAudioElement,
        // outputGuardrails: [guardrail],
        // extraContext: {
        //   addTranscriptBreadcrumb,
        // },
      });
    } catch (err) {
      console.error("Error connecting via SDK:", err);
      setSessionStatus("DISCONNECTED");
    }
    return;
  };

  const disconnectFromRealtime = () => {
    disconnect();
    setSessionStatus("DISCONNECTED");
    setIsPTTUserSpeaking(false);
  };

  const sendSimulatedUserMessage = (text: string) => {
    const id = uuidv4().slice(0, 32);
    addTranscriptMessage(id, "user", text, true);

    sendClientEvent({
      type: "conversation.item.create",
      item: {
        id,
        type: "message",
        role: "user",
        content: [{ type: "input_text", text }],
      },
    });
    sendClientEvent(
      { type: "response.create" },
      "(simulated user text message)",
    );
  };

  const updateSession = (shouldTriggerResponse: boolean = false) => {
    // Reflect Push-to-Talk UI state by (de)activating server VAD on the
    // backend. The Realtime SDK supports live session updates via the
    // `session.update` event.
    const turnDetection = isPTTActive
      ? null
      : {
          type: "server_vad",
          threshold: 0.9,
          prefix_padding_ms: 300,
          silence_duration_ms: 500,
          create_response: true,
        };

    sendEvent({
      type: "session.update",
      session: {
        turn_detection: turnDetection,
      },
    });

    // Send an initial 'hi' message to trigger the agent to greet the user
    if (shouldTriggerResponse) {
      sendSimulatedUserMessage("hi");
    }
    return;
  };

  const handleSendTextMessage = () => {
    if (!userText.trim()) return;
    interrupt();

    try {
      sendUserText(userText.trim());
    } catch (err) {
      console.error("Failed to send via SDK", err);
    }

    setUserText("");
  };

  const handleTalkButtonDown = () => {
    if (sessionStatus !== "CONNECTED") return;
    interrupt();

    setIsPTTUserSpeaking(true);
    sendClientEvent({ type: "input_audio_buffer.clear" }, "clear PTT buffer");

    // No placeholder; we'll rely on server transcript once ready.
  };

  const handleTalkButtonUp = () => {
    if (sessionStatus !== "CONNECTED" || !isPTTUserSpeaking) return;

    setIsPTTUserSpeaking(false);
    sendClientEvent({ type: "input_audio_buffer.commit" }, "commit PTT");
    sendClientEvent({ type: "response.create" }, "trigger response PTT");
  };

  const onToggleConnection = () => {
    if (sessionStatus === "CONNECTED" || sessionStatus === "CONNECTING") {
      disconnectFromRealtime();
      setSessionStatus("DISCONNECTED");
    } else {
      connectToRealtime();
    }
  };

  // Because we need a new connection, refresh the page when codec changes
  const handleCodecChange = (newCodec: string) => {
    const url = new URL(window.location.toString());
    url.searchParams.set("codec", newCodec);
    window.location.replace(url.toString());
  };

  useEffect(() => {
    const storedPushToTalkUI = localStorage.getItem("pushToTalkUI");
    if (storedPushToTalkUI) {
      setIsPTTActive(storedPushToTalkUI === "true");
    }
    const storedLogsExpanded = localStorage.getItem("logsExpanded");
    if (storedLogsExpanded) {
      setIsEventsPaneExpanded(storedLogsExpanded === "true");
    }
    const storedAudioPlaybackEnabled = localStorage.getItem(
      "audioPlaybackEnabled",
    );
    if (storedAudioPlaybackEnabled) {
      setIsAudioPlaybackEnabled(storedAudioPlaybackEnabled === "true");
    }
  }, []);

  useEffect(() => {
    localStorage.setItem("pushToTalkUI", isPTTActive.toString());
  }, [isPTTActive]);

  useEffect(() => {
    localStorage.setItem("logsExpanded", isEventsPaneExpanded.toString());
  }, [isEventsPaneExpanded]);

  useEffect(() => {
    localStorage.setItem(
      "audioPlaybackEnabled",
      isAudioPlaybackEnabled.toString(),
    );
  }, [isAudioPlaybackEnabled]);

  useEffect(() => {
    if (audioElementRef.current) {
      if (isAudioPlaybackEnabled) {
        audioElementRef.current.muted = false;
        audioElementRef.current.play().catch((err) => {
          console.warn("Autoplay may be blocked by browser:", err);
        });
      } else {
        // Mute and pause to avoid brief audio blips before pause takes effect.
        audioElementRef.current.muted = true;
        audioElementRef.current.pause();
      }
    }

    // Toggle server-side audio stream mute so bandwidth is saved when the
    // user disables playback.
    try {
      mute(!isAudioPlaybackEnabled);
    } catch (err) {
      console.warn("Failed to toggle SDK mute", err);
    }
  }, [isAudioPlaybackEnabled]);

  // Ensure mute state is propagated to transport right after we connect or
  // whenever the SDK client reference becomes available.
  useEffect(() => {
    if (sessionStatus === "CONNECTED") {
      try {
        mute(!isAudioPlaybackEnabled);
      } catch (err) {
        console.warn("mute sync after connect failed", err);
      }
    }
  }, [sessionStatus, isAudioPlaybackEnabled]);

  useEffect(() => {
    if (sessionStatus === "CONNECTED" && audioElementRef.current?.srcObject) {
      // The remote audio stream from the audio element.
      const remoteStream = audioElementRef.current.srcObject as MediaStream;
      startRecording(remoteStream);
    }

    // Clean up on unmount or when sessionStatus is updated.
    return () => {
      stopRecording();
    };
  }, [sessionStatus]);

  // Cleanup effect to disconnect session when component unmounts
  // useEffect(() => {
  //   return () => {
  //     if (sessionStatus === "CONNECTED" || sessionStatus === "CONNECTING") {
  //       disconnectFromRealtime();
  //       setSessionStatus("DISCONNECTED");
  //     }
  //   };
  // }, []);
  useEffect(() => {
    // This effect runs when the component mounts and when location.pathname changes
    console.log("Location changed:", location.pathname);

    // Return cleanup function that will run on unmount OR when location.pathname changes
    return () => {
      console.log("Cleaning up - current sessionStatus:", sessionStatus);

      // Always try to disconnect and stop recording, regardless of current state
      // because the state might be stale in the cleanup function
      try {
        disconnect();
        stopRecording();
        setSessionStatus("DISCONNECTED");
        setIsPTTUserSpeaking(false);
      } catch (error) {
        console.error("Error during cleanup:", error);
      }
    };
  }, [location.pathname]);
  if (isInitializing || isLoading) {
    return (
      <ModernDashboardLayout>
        <div className="min-h-screen bg-white flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              Preparing Your Session...
            </h3>
          </div>
        </div>
      </ModernDashboardLayout>
    );
  }
  console.log(scenario);
  return (
    <ModernDashboardLayout>
      <div>
        <Link
          to={`/avatar/practice/pre-session${location.search}`}
          className="inline-flex items-center text-blue-600 hover:text-blue-700 mb-4 font-medium"
        >
          ← Back Pre Session
        </Link>
      </div>
      <div className="text-base flex flex-col h-[80vh] bg-gray-100 text-gray-800 relative">
          <div className='pt-4 px-4'>
            {scenario.name && <p className='font-semibold'>Scenario: <span className='font-normal'>
              {scenario.name}
            </span>
            </p>}
            {scenario.description && <p className='font-semibold'>Context: <span className='font-normal'>
              {scenario.description}
            </span> 
            </p>}
          </div>
        <div className="p-5 text-lg font-semibold flex justify-between items-center">
          <div className="flex items-center justify-between w-full gap-2">
            <div className="flex items-center gap-4">
              <span>AI <span className="text-gray-500">Roleplay</span></span>
              {languageFromParams && languageFromParams !== "en" && (
                <div className="flex items-center gap-1.5 px-2.5 py-1 bg-blue-50 text-blue-700 rounded-full text-sm font-medium" data-testid="language-indicator">
                  <Globe className="w-4 h-4" />
                  <span>{languageNames[languageFromParams] || languageFromParams.toUpperCase()}</span>
                </div>
              )}
            </div>
            <div>
              <p className="my-2">
                {" "}
                {scenario.avatarRole && (
                  <>
                    {" "}
                    <span className="font-semibold">
                      {scenario.avatarRole}
                    </span>{" "}
                  </>
                )}{" "}
              </p>
            </div>
          </div>
        </div>

        <>
          {/* userText={userText}
            setUserText={setUserText}
            onSendMessage={handleSendTextMessage}
            downloadRecording={downloadRecording}
            canSend={sessionStatus === "CONNECTED"} */}
          <Transcript
            avatar={avatarData}
            sessionStatus={sessionStatus}
            onToggleConnection={onToggleConnection}
            scenario={scenario}
            downloadRecording={downloadRecording}
            generateBlob={generateBlob}
          />
        </>

        {/* <BottomToolbar
          sessionStatus={sessionStatus}
          onToggleConnection={onToggleConnection}
          isPTTActive={isPTTActive}
          setIsPTTActive={setIsPTTActive}
          isPTTUserSpeaking={isPTTUserSpeaking}
          handleTalkButtonDown={handleTalkButtonDown}
          handleTalkButtonUp={handleTalkButtonUp}
          isEventsPaneExpanded={isEventsPaneExpanded}
          setIsEventsPaneExpanded={setIsEventsPaneExpanded}
          isAudioPlaybackEnabled={isAudioPlaybackEnabled}
          setIsAudioPlaybackEnabled={setIsAudioPlaybackEnabled}
          codec={urlCodec}
          onCodecChange={handleCodecChange}
        /> */}
      </div>
    </ModernDashboardLayout>
  );
};
