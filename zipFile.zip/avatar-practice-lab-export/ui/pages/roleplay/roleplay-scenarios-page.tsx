import React, { useCallback, useMemo, useState } from "react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Sparkles, Timer, Target, PlayCircle, NotebookPen } from "lucide-react";
// Note: This import is commented out as it's not available in the current OpenAI SDK
// If you need realtime functionality, check the latest OpenAI SDK documentation
// import { RealtimeAgent } from "openai/realtime";
 import { useParams, useNavigate } from "react-router-dom";
 
import ModernDashboardLayout from "@/components/layout/modern-dashboard-layout";

// --- UI Component -----------------------------------------------------------
export const SCENARIOS = [
  {
    key: "focus",
    title: "Focus & Distraction Control",
    description: "Reduce context switching, build a repeatable focus routine.",
     
    chips: ["Deep work", "Study blocks", "Environment"],
  },
  {
    key: "exam",
    title: "Exam Strategy & Time Management",
    description: "Plan, practice, and pace for upcoming exams.",
     chips: ["Pacing", "Question triage", "Mock tests"],
  },
  {
    key: "confidence",
    title: "Confidence & Presentation Skills",
    description: "Reduce anxiety, structure talking points, improve delivery.",
     chips: ["Rehearsal", "Story arcs", "Voice & posture"],
  },
] as const;

export default function AvatarRoleplayScenariosPage() {
  const [notes, setNotes] = useState("");
  const [learnerName, setLearnerName] = useState("");
  const [activeTopic, setActiveTopic] = useState<string | null>(null);
  const [preview, setPreview] = useState<string>("");
   const navigate = useNavigate();

  const handlePreview = useCallback((topicTitle: string) => {
    setActiveTopic(topicTitle);
    const p = buildCoachPrompt(topicTitle, notesWithName(notes, learnerName));
    setPreview(p);
  }, [notes, learnerName]);

  const handleStart = (key)=>{
    navigate(`/avatar/roleplay/practice?scenario=${encodeURIComponent(key)}`)
  }

  const topicBadges = useCallback((chips: string[]) => (
    <div className="flex flex-wrap gap-2 mt-2">
      {chips.map((c) => (
        <Badge key={c} variant="secondary" className="rounded-2xl px-3 py-1 text-xs">{c}</Badge>
      ))}
    </div>
  ), []);

  return (
    <ModernDashboardLayout>
    <div className="w-full max-w-6xl mx-auto p-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {SCENARIOS.map((s) => (
          <Card key={s.key} className="rounded-2xl shadow-sm">
            <CardHeader>
              <div className="flex items-center gap-2">
                 <CardTitle className="text-lg">{s.title}</CardTitle>
              </div>
              <CardDescription>{s.description}</CardDescription>
              {topicBadges(s.chips)}
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <Label htmlFor={`notes-${s.key}`} className="text-sm">Optional notes/context</Label>
                <Textarea id={`notes-${s.key}`} placeholder="e.g., finals on Sept 12, struggles after 20 minutes, prefers morning study…" value={notes} onChange={(e) => setNotes(e.target.value)} className="min-h-[96px]" />
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="learner-name">Learner name (optional)</Label>
                    <Input id="learner-name" placeholder="e.g., Samira" value={learnerName} onChange={(e) => setLearnerName(e.target.value)} />
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex items-center justify-between gap-3">
              
              <Button onClick={() => handleStart(s.key)}>
                <PlayCircle className="mr-2 h-4 w-4" /> Start Session
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>

      {/* {activeTopic && (
        <div className="mt-8">
          <h3 className="text-base font-semibold">Prompt Preview</h3>
          <p className="text-sm text-muted-foreground">Topic: {activeTopic}</p>
          <Separator className="my-3" />
          <pre className="whitespace-pre-wrap text-sm p-4 bg-muted rounded-xl border overflow-auto max-h-[360px]">{preview}</pre>
        </div>
      )} */}
    </div>
    </ModernDashboardLayout>
  );
}

// Helper to optionally inject learner name into the Extra Context block
function notesWithName(notes: string, learnerName: string) {
  const trimmed = notes?.trim();
  const nameLine = learnerName ? `Learner: ${learnerName}` : "";
  return [nameLine, trimmed].filter(Boolean).join("\n");
}
