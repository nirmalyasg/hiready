import {
  pgTable,
  text,
  serial,
  integer,
  boolean,
  jsonb,
  timestamp,
  smallint,
  varchar,
  real,
  primaryKey,
  numeric,
  uuid,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { relations, sql } from "drizzle-orm";
import { z } from "zod";

// =====================
// Core Tables
// =====================

// Users (minimal for FK references)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  displayName: text("display_name"),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at"),
});

// Skills (scenarios reference these)
export const skills = pgTable("skills", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  definition: text("definition").notNull(),
  level: integer("level").notNull(),
  parentSkillId: integer("parent_skill_id"),
  category: text("category").default("General"),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at"),
});

// =====================
// Avatar Practice Lab Tables
// =====================

export const scenarios = pgTable("scenarios", {
  id: serial("id").primaryKey(),
  skillId: integer("skill_id").references(() => skills.id),
  name: varchar("name").notNull(),
  description: text("description"),
  context: text("context"),
  instructions: text("instructions"),
  avatarName: varchar("avatar_name"),
  avatarRole: varchar("avatar_role"),
  difficulty: text("difficulty"),
  duration: numeric("duration"),
});

export const scenarioSkills = pgTable(
  "scenario_skills",
  {
    scenarioId: integer("scenario_id")
      .references(() => scenarios.id, { onDelete: "cascade" })
      .notNull(),
    skillId: integer("skill_id")
      .references(() => skills.id, { onDelete: "cascade" })
      .notNull(),
  },
  (t) => ({
    pk: primaryKey({ columns: [t.scenarioId, t.skillId] }),
  }),
);

export const personas = pgTable("personas", {
  id: serial("id").primaryKey(),
  persona: varchar("persona").notNull(),
  description: text("description"),
});

export const tones = pgTable("tones", {
  id: serial("id").primaryKey(),
  tone: varchar("tone").notNull(),
  description: text("description"),
});

export const avatars = pgTable("avatars", {
  id: varchar("id").primaryKey(),
  name: varchar("name"),
  look: varchar("look"),
  ethnicity: varchar("ethnicity"),
  gender: varchar("gender"),
  role: varchar("role"),
  imageUrl: text("image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// =====================
// Session Management
// =====================

export const roleplaySession = pgTable("roleplay_session", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade", onUpdate: "cascade" }),
  avatarId: varchar("avatar_id")
    .notNull()
    .references(() => avatars.id),
  knowledgeId: varchar("knowledge_id"),
  transcriptId: varchar("transcript_id"),
  startTime: timestamp("start_time").defaultNow().notNull(),
  endTime: timestamp("end_time").defaultNow(),
  duration: integer("duration"),
  audioUrl: varchar("audio_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const aiSessions = pgTable("ai_sessions", {
  id: uuid("id").defaultRandom().primaryKey(),
  sessionType: text("session_type").notNull(),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id, { onUpdate: "cascade", onDelete: "cascade" }),
  avatarId: varchar("avatar_id"),
  knowledgeId: varchar("knowledge_id"),
  startTime: timestamp("start_time").defaultNow().notNull(),
  endTime: timestamp("end_time"),
  duration: integer("duration"),
  audioUrl: text("audio_url"),
  createdAt: timestamp("created_at", { withTimezone: false }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: false }).defaultNow().notNull(),
});

export const transcripts = pgTable("transcripts", {
  id: varchar("id").primaryKey(),
  avatarId: varchar("avatar_id").notNull(),
  knowledgeId: varchar("knowledge_id"),
  context: text("context"),
  instructions: text("instructions"),
  scenario: text("scenario"),
  skill: text("skill"),
  duration: integer("duration"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id, { onUpdate: "cascade", onDelete: "cascade" }),
  sessionId: varchar("session_id")
    .notNull()
    .references(() => roleplaySession.id, { onDelete: "cascade" }),
  aiSessionId: uuid("ai_session_id").references(() => aiSessions.id, {
    onUpdate: "cascade",
    onDelete: "cascade",
  }),
  skillId: integer("skill_id"),
  scenarioId: integer("scenario_id").references(() => scenarios.id, { onDelete: "set null" }),
  sessionType: varchar("session_type").default("streaming_avatar"),
});

export const transcriptMessages = pgTable("transcript_messages", {
  id: text("id").primaryKey(),
  transcriptId: text("transcript_id")
    .references(() => transcripts.id)
    .notNull(),
  messages: jsonb("messages").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const aiSessionAnalysis = pgTable("ai_session_analysis", {
  id: serial("id").primaryKey(),
  sessionId: integer("session_id")
    .references(() => roleplaySession.id)
    .notNull(),
  sessionType: text("session_type").default("audio_roleplay").notNull(),
  transcriptId: varchar("transcript_id").references(() => transcripts.id),
  overallScore: integer("overall_score").notNull(),
  userTalkTime: real("user_talk_time").notNull(),
  otherTalkTime: real("other_talk_time").notNull(),
  userTalkPercentage: real("user_talk_percentage").notNull(),
  fillerWords: jsonb("filler_words").notNull(),
  weakWords: jsonb("weak_words").notNull(),
  sentenceOpeners: jsonb("sentence_openers").notNull(),
  activeListening: boolean("active_listening").notNull(),
  engagementLevel: integer("engagement_level").notNull(),
  questionsAsked: integer("questions_asked").notNull(),
  acknowledgments: integer("acknowledgments").notNull(),
  interruptions: integer("interruptions").notNull(),
  averagePacing: real("average_pacing").notNull(),
  pacingVariation: jsonb("pacing_variation").notNull(),
  tone: jsonb("tone").notNull(),
  pauseCount: integer("pause_count").notNull(),
  averagePauseLength: real("average_pause_length").notNull(),
  strengths: jsonb("strengths").notNull(),
  growthAreas: jsonb("growth_areas").notNull(),
  followUpQuestions: jsonb("follow_up_questions").notNull(),
  summary: text("summary").notNull(),
  pronunciationIssues: jsonb("pronunciation_issues").notNull(),
  pronunciationSuggestions: jsonb("pronunciation_suggestions").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// =====================
// HeyGen Session Management
// =====================

export const heygenSessions = pgTable("heygen_sessions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  scenarioId: integer("scenario_id")
    .references(() => scenarios.id, { onDelete: "set null" }),
  avatarId: varchar("avatar_id")
    .references(() => avatars.id),
  heygenSessionId: varchar("heygen_session_id"),
  status: text("status")
    .$type<"active" | "ended" | "stale" | "error" | "expired">()
    .notNull()
    .default("active"),
  mode: text("mode")
    .$type<"voice" | "video">()
    .notNull()
    .default("voice"),
  quality: text("quality")
    .$type<"low" | "medium" | "high">()
    .default("low"),
  startedAt: timestamp("started_at").defaultNow().notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  endedAt: timestamp("ended_at"),
  lastSeenAt: timestamp("last_seen_at").defaultNow(),
  sessionDurationSec: integer("session_duration_sec").default(360),
  actualDurationSec: integer("actual_duration_sec"),
  endReason: text("end_reason")
    .$type<"user_ended" | "timeout" | "error" | "stale" | "admin">(),
  metadata: jsonb("metadata").$type<{
    knowledgeId?: string;
    knowledgeBase?: string;
    language?: string;
    userAgent?: string;
    ipAddress?: string;
  }>(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const heygenQueue = pgTable("heygen_queue", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  scenarioId: integer("scenario_id")
    .references(() => scenarios.id, { onDelete: "set null" }),
  avatarId: varchar("avatar_id")
    .references(() => avatars.id),
  status: text("status")
    .$type<"queued" | "assigned" | "cancelled" | "expired">()
    .notNull()
    .default("queued"),
  mode: text("mode")
    .$type<"voice" | "video">()
    .notNull()
    .default("voice"),
  priority: smallint("priority").default(0),
  queuedAt: timestamp("queued_at").defaultNow().notNull(),
  assignedAt: timestamp("assigned_at"),
  expiresAt: timestamp("expires_at"),
  assignedSessionId: integer("assigned_session_id")
    .references(() => heygenSessions.id, { onDelete: "set null" }),
  estimatedWaitSec: integer("estimated_wait_sec"),
  metadata: jsonb("metadata").$type<{
    knowledgeId?: string;
    knowledgeBase?: string;
    language?: string;
  }>(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// =====================
// Relations
// =====================

export const heygenSessionsRelations = relations(heygenSessions, ({ one }) => ({
  user: one(users, {
    fields: [heygenSessions.userId],
    references: [users.id],
  }),
  scenario: one(scenarios, {
    fields: [heygenSessions.scenarioId],
    references: [scenarios.id],
  }),
  avatar: one(avatars, {
    fields: [heygenSessions.avatarId],
    references: [avatars.id],
  }),
}));

export const heygenQueueRelations = relations(heygenQueue, ({ one }) => ({
  user: one(users, {
    fields: [heygenQueue.userId],
    references: [users.id],
  }),
  scenario: one(scenarios, {
    fields: [heygenQueue.scenarioId],
    references: [scenarios.id],
  }),
  avatar: one(avatars, {
    fields: [heygenQueue.avatarId],
    references: [avatars.id],
  }),
  assignedSession: one(heygenSessions, {
    fields: [heygenQueue.assignedSessionId],
    references: [heygenSessions.id],
  }),
}));

// =====================
// Insert Schemas
// =====================

export const insertScenarioSchema = createInsertSchema(scenarios).omit({ id: true });
export const insertPersonaSchema = createInsertSchema(personas).omit({ id: true });
export const insertToneSchema = createInsertSchema(tones).omit({ id: true });
export const insertAvatarSchema = createInsertSchema(avatars);
export const insertRoleplaySessionSchema = createInsertSchema(roleplaySession).omit({ id: true, createdAt: true, updatedAt: true });
export const insertTranscriptSchema = createInsertSchema(transcripts);
export const insertTranscriptMessageSchema = createInsertSchema(transcriptMessages);
export const insertAiSessionAnalysisSchema = createInsertSchema(aiSessionAnalysis).omit({ id: true, createdAt: true, updatedAt: true });
export const insertHeygenSessionSchema = createInsertSchema(heygenSessions).omit({ id: true, createdAt: true, updatedAt: true });
export const insertHeygenQueueSchema = createInsertSchema(heygenQueue).omit({ id: true, createdAt: true, updatedAt: true });

// =====================
// Types
// =====================

export type Scenario = typeof scenarios.$inferSelect;
export type InsertScenario = z.infer<typeof insertScenarioSchema>;
export type Persona = typeof personas.$inferSelect;
export type InsertPersona = z.infer<typeof insertPersonaSchema>;
export type Tone = typeof tones.$inferSelect;
export type InsertTone = z.infer<typeof insertToneSchema>;
export type Avatar = typeof avatars.$inferSelect;
export type InsertAvatar = z.infer<typeof insertAvatarSchema>;
export type RoleplaySession = typeof roleplaySession.$inferSelect;
export type InsertRoleplaySession = z.infer<typeof insertRoleplaySessionSchema>;
export type Transcript = typeof transcripts.$inferSelect;
export type InsertTranscript = z.infer<typeof insertTranscriptSchema>;
export type TranscriptMessage = typeof transcriptMessages.$inferSelect;
export type InsertTranscriptMessage = z.infer<typeof insertTranscriptMessageSchema>;
export type AiSessionAnalysis = typeof aiSessionAnalysis.$inferSelect;
export type InsertAiSessionAnalysis = z.infer<typeof insertAiSessionAnalysisSchema>;
export type HeygenSession = typeof heygenSessions.$inferSelect;
export type InsertHeygenSession = z.infer<typeof insertHeygenSessionSchema>;
export type HeygenQueue = typeof heygenQueue.$inferSelect;
export type InsertHeygenQueue = z.infer<typeof insertHeygenQueueSchema>;
