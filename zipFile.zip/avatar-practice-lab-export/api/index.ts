import express from "express";
import { avatarSimulator } from "./routes/avatar-simulator";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Mount avatar simulator routes
app.use("/api/avatar", avatarSimulator);

// Health check
app.get("/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

app.listen(PORT, () => {
  console.log(`Avatar Practice Lab server running on port ${PORT}`);
});

export default app;
